package com.example.fullstack.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FullstackApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
